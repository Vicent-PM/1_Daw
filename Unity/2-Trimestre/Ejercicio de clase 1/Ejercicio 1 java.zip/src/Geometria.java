public interface Geometria {
    public double calcularPerimetro();
    public double calcularArea();
}
