package com.example.trabajowebview

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import com.example.trabajowebview.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val webView = binding.web
        val ajustes = webView.settings

        webView.loadUrl("https://es.wikipedia.org/")

        ajustes.javaScriptEnabled = true

        //Boton para ir hacia atras
        binding.imageButton.setOnClickListener {
            if (webView.canGoBack() && binding.imageButton.isEnabled) {
                webView.goBack()
            }
        }

        //Desabilitar boton si no se puede ir para atras
        if(!webView.canGoBack()){
            binding.imageButton.isEnabled = false
        }

        //Boton para ir hacia delante
        binding.imageButton2.setOnClickListener {
            if (webView.canGoForward() && binding.imageButton2.isEnabled) {
                webView.goForward()
            }
        }

        //Desabilitar boton si no se puede ir hacia delante
        if(!webView.canGoForward()){
            binding.imageButton2.isEnabled = false
        }

        //Boton para abrir en el navegador
        binding.imageButton3.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(webView.url))
            startActivity(intent)
        }

        //Boton para recargar la pagina
        binding.imageButton4.setOnClickListener {
            webView.reload()
        }

        //Poner titulo en el textview
        webView.webChromeClient = object : WebChromeClient() {
            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                binding.textView.text = title
            }

            //Barra de progreso con carga
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                super.onProgressChanged(view, newProgress)
                binding.progressBar.progress = newProgress
                if (binding.progressBar.progress != 100) {
                    binding.progressBar.visibility = View.VISIBLE
                }
            }
        }

        //Cargar todas las urls en el webview
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                return super.shouldOverrideUrlLoading(view, request)
            }
            // Si la pagina a terminado de cargar que la barra de progreso se ponga en gone
            override fun onPageFinished(view: WebView?, url: String?) {
                binding.progressBar.visibility = View.GONE
            }
        }
        //Funcion para utilizar el boton fisico
        onBackPressedDispatcher.addCallback(this, object: OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if(webView.canGoBack()){
                    webView.goBack()
                } else{
                    val builder = AlertDialog.Builder(this@MainActivity)
                    builder.setTitle("Cerrar App")
                    builder.setMessage("¿Quieres salir de la aplicacion?")
                    builder.setNegativeButton("No", null)
                    builder.setPositiveButton("Si") { dialog, wich -> finish() }
                    val dialog = builder.create()
                    dialog.show()
                }
            }
        })

        //Pulsacion larga para volver a la primera pagina
        binding.imageButton.setOnLongClickListener {
            val historial = webView.copyBackForwardList()
            if (historial.size > 0 && historial.currentIndex != 0) {
                webView.goBackOrForward(-historial.currentIndex)
                true
            } else {
                false
            }
        }

        //Pulsacion larga para ir a la ultima pagina
        binding.imageButton2.setOnLongClickListener {
            val historial = webView.copyBackForwardList()
            if (historial.size > 0 && historial.currentIndex != historial.size - 1) {
                webView.goBackOrForward(historial.size - 1 - historial.currentIndex)
                true
            } else {
                false
            }
        }
    }
}

