package com.example.dolcevita

import android.content.Intent
import android.graphics.drawable.AnimationDrawable
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.dolcevita.databinding.SecondActivityBinding

class SecondActivity: AppCompatActivity() {

    lateinit var binding: SecondActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = SecondActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button1.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.data = Uri.parse("https://estaticos.qdq.com/swdata/files/486/486981590/CARTAS-CAFETERIA-TODAS-EN-UNO.pdf")
            startActivity(intent)
        }

        val u = getIntent().extras
        val usuario = u!!.getString("userName")
        binding.textView.setText(binding.textView.text.toString() + usuario)
    }
}