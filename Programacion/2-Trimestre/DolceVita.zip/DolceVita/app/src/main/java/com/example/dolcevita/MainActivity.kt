package com.example.dolcevita

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.dolcevita.databinding.ActivityMainBinding
import com.example.dolcevita.databinding.SecondActivityBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button1.setOnClickListener {
            val userName = binding.userId.text.toString()
            if(binding.userId.text.isNullOrBlank() || binding.passwordId.text.isNullOrBlank()){
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            } else{
                if(binding.passwordId.text.toString() != "dolcevita" || binding.userId.text.toString() != "Vicente"){
                    Toast.makeText(this, "La  y/o usuario es incorrecto", Toast.LENGTH_SHORT).show()
                } else{
                    Toast.makeText(this, "Sesion iniciada correctamente, bienvenido $userName.", Toast.LENGTH_SHORT).show()
                    val intent = Intent(this, SecondActivity::class.java)
                    intent.putExtra("userName", userName)
                    startActivity(intent)
                    finish()
                }
            }
        }

        binding.button2.setOnClickListener {
            noContentButton()
        }

        binding.button3.setOnClickListener {
            noContentButton()
        }
    }

    private fun noContentButton(){
        Toast.makeText(this, "Este apartado esta en desarrollo. Gracias!", Toast.LENGTH_SHORT).show()
    }
}