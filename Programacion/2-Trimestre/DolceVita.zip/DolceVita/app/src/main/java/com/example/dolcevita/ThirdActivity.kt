package com.example.dolcevita

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.appcompat.app.AppCompatActivity
import com.example.dolcevita.databinding.ThirdActivityBinding

class ThirdActivity: AppCompatActivity() {

    lateinit var binding: ThirdActivityBinding
    lateinit var webView: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ThirdActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)

        webView = binding.webView

        webView.loadUrl("https://www.cafeclock.com/our-food")

        binding.imageButton.setOnClickListener {
            finish()
        }
    }

}