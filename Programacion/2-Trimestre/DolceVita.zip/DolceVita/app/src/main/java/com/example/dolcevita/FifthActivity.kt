package com.example.dolcevita

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.dolcevita.databinding.FifthActivityBinding
import com.example.dolcevita.databinding.FourthActivityBinding

class FifthActivity: AppCompatActivity() {

    lateinit var binding: FifthActivityBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = FifthActivityBinding.inflate(layoutInflater)
        setContentView(binding.root)


    }
}