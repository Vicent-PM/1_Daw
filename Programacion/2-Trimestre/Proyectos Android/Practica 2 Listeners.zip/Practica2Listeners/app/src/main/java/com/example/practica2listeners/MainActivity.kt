package com.example.practica2listeners

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.practica2listeners.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        val view = binding.root
        setContentView(view)

        //Boton Sumar
        binding.button.setOnClickListener {
            var numero = binding.textView3.text.toString().toInt()
            numero += binding.editTextTextPersonName2.text.toString().toInt()
            binding.textView3.setText(numero.toString())
        }

        //Boton Restar
        binding.button2.setOnClickListener {
            var numero = binding.textView3.text.toString().toInt()
            numero -= binding.editTextTextPersonName2.text.toString().toInt()
            binding.textView3.setText(numero.toString())
        }

        //Ingresa un numero para sumar o restar

        binding.editTextTextPersonName2.addTextChangedListener(object : TextWatcher{
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {

            }

            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                binding.button.text = "+" + binding.editTextTextPersonName2.text.toString()
                binding.button2.text = "-" + binding.editTextTextPersonName2.text.toString()
                if(binding.editTextTextPersonName2.text.isNullOrBlank()){
                    binding.editTextTextPersonName2.setText("1")
                }
            }

            override fun afterTextChanged(s: Editable?) {

            }

        })

        binding.seekBar3.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                var numero = binding.seekBar3.progress + 111
                binding.textView3.setText(numero.toString())
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
            }

        })

        binding.switch1.setOnClickListener {
            if(binding.switch1.isChecked){
                binding.textView3.visibility = View.INVISIBLE
            } else{
                binding.textView3.visibility = View.VISIBLE
            }
        }

        binding.toggleButton.setOnClickListener {
            if(binding.toggleButton.isChecked){
                binding.cardView.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white))
                binding.textView2.setTextColor(ContextCompat.getColor(this, R.color.black))
                binding.textView3.setTextColor(ContextCompat.getColor(this, R.color.red))
                binding.editTextTextPersonName2.setTextColor(ContextCompat.getColor(this, R.color.black))
                binding.editTextTextPersonName2.setHintTextColor(ContextCompat.getColor(this, R.color.black))
                binding.seekBar3.setBackgroundColor(ContextCompat.getColor(this, R.color.white))
                binding.cardView2.setCardBackgroundColor(ContextCompat.getColor(this, R.color.white))
                binding.switch1.setTextColor(ContextCompat.getColor(this, R.color.black))
            } else{
                binding.cardView.setCardBackgroundColor(ContextCompat.getColor(this, R.color.fondoCard))
                binding.textView2.setTextColor(ContextCompat.getColor(this, R.color.white))
                binding.textView3.setTextColor(ContextCompat.getColor(this, R.color.white))
                binding.editTextTextPersonName2.setTextColor(ContextCompat.getColor(this, R.color.white))
                binding.editTextTextPersonName2.setHintTextColor(ContextCompat.getColor(this, R.color.white))
                binding.seekBar3.setBackgroundColor(ContextCompat.getColor(this, R.color.fondoCard))
                binding.cardView2.setCardBackgroundColor(ContextCompat.getColor(this, R.color.fondoCard))
                binding.switch1.setTextColor(ContextCompat.getColor(this, R.color.white))
            }
        }

        binding.button3.setOnClickListener {
            if(!binding.editTextTextPersonName3.text.isNullOrEmpty() && (binding.radioButton.isChecked || binding.radioButton2.isChecked)){
                if(binding.radioButton.isChecked){
                    var resultado = binding.editTextTextPersonName3.text.toString().toDouble() * 1.09
                    binding.textView7.setText(String.format("%.2f", resultado) + "$")
                }

                if(binding.radioButton2.isChecked){
                    var resultado = binding.editTextTextPersonName3.text.toString().toDouble() * 0.92
                    binding.textView7.setText(String.format("%.2f", resultado) + "€")
                }
            } else{
                Toast.makeText(this, "Faltan campos por rellenar", Toast.LENGTH_SHORT).show()
            }
        }

        binding.button4.setOnClickListener {
            binding.editTextTextPersonName3.setText("")
            binding.radioButton.isChecked = false
            binding.radioButton2.isChecked = false
            binding.textView7.setText("0")
        }

    }
}