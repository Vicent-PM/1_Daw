package com.example.examen2023feb

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.examen2023feb.databinding.ActivityLoginBinding


/**
 * Created by sergi on 28/03/2022.
 */

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val bt_entrar = findViewById<Button>(R.id.login_btn_login)
        bt_entrar.setOnClickListener {
            val usertext = binding.loginEdUser.text.toString()
            val passtext = binding.loginEdPass.text.toString()
            compruebaLogin(usertext, passtext)
        }


//        todo autologin para testear
        abrirMainActivity("Usuario")

        binding.floatingActionButton.setOnClickListener {
            val intentLlamar = Intent(Intent.ACTION_DIAL)
            intentLlamar.data = Uri.parse("tel: 666555444")
            startActivity(intentLlamar)
        }

    }

    private fun compruebaLogin(user: String, pass: String) {

        if (user.isEmpty()) {
            binding.loginEdUser.error = "El campo está vacío"
            return
        }
        if (pass.isEmpty()) {
            binding.loginEdPass.error = "El campo está vacío"
            return
        }

        if(!binding.checkBox.isChecked){
            binding.checkBox.error = "Debes aceptarme"
            return
        }

        if (pass == "12345") {
            abrirMainActivity(user)
            finish()
        } else{
            binding.loginEdPass.error = "Contraseña incorrecta"
            return
        }
    }

    private fun abrirMainActivity(usuario: String) {
        val intent = Intent(this, MainActivity::class.java)
        intent.putExtra("user", usuario)
        startActivity(intent)
    }
}