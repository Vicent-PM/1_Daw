package com.example.morosos

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.LinearLayout
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.morosos.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val listaMoroso = ArrayList<Moroso>()

        val layoutManager = LinearLayoutManager(this)
        binding.recyclerView.layoutManager = layoutManager

        val adapter = MorosoAdapter()
        binding.recyclerView.adapter = adapter

        binding.button.setOnClickListener {
            val nombre = binding.nombre.text.toString()
            val cantidad = binding.cantidad.text.toString().toDouble()
            val moroso = Moroso(nombre, cantidad)
            adapter.addMoroso(moroso)
        }

        binding.button2.setOnClickListener {
            adapter.clearList()
        }
    }
}