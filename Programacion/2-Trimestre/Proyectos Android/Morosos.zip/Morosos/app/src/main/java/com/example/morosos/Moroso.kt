package com.example.morosos

data class Moroso(
    val nombre: String,
    var cantidad: Double
)


