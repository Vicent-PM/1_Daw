package com.example.morosos

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView.Adapter
import androidx.recyclerview.widget.RecyclerView.ViewHolder
import com.example.morosos.databinding.HolderMorososBinding

class MorosoAdapter() : Adapter<MorosoAdapter.CeldaMoroso>() {

    val listaMoroso = ArrayList<Moroso>()

    inner class CeldaMoroso(val binding: HolderMorososBinding) : ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CeldaMoroso {
        val inflater = LayoutInflater.from(parent.context)
        val binding = HolderMorososBinding.inflate(inflater, parent, false)
        val celda = CeldaMoroso(binding)
        return celda
    }

    override fun getItemCount(): Int {
        return listaMoroso.size
    }

    override fun onBindViewHolder(holder: CeldaMoroso, position: Int) {
        val moroso = listaMoroso[position]
        holder.binding.textView.text = moroso.nombre
        holder.binding.textView2.text = moroso.cantidad.toString()

        holder.binding.imageButton.setOnClickListener {
            listaMoroso.removeAt(position)
            notifyItemRemoved(position)
            notifyItemRangeChanged(position, listaMoroso.size)
        }
    }

    fun addMoroso(moroso: Moroso){
        listaMoroso.add(moroso)
        notifyItemInserted(listaMoroso.size - 1)
    }

    fun clearList(){
        listaMoroso.clear()
        notifyDataSetChanged()
    }


}